import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Lab2_PersonalInfoWriter {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter your name: ");
        String name = input.nextLine();

        System.out.print("Enter your age: ");
        int age = input.nextInt();
        input.nextLine();

        System.out.print("Enter your email: ");
        String email = input.nextLine();

        File folder = new File("labfiles");
        folder.mkdirs();

        try {
            FileWriter writer = new FileWriter("labfiles/profile.txt");

            writer.write("Personal Information\n");
            writer.write("Name: " + name + "\n");
            writer.write("Age: " + age + "\n");
            writer.write("Email: " + email + "\n");

            writer.close();

            System.out.println("Information saved successfully.");
        } catch (IOException e) {
            System.out.println("An error occurred: " + e.getMessage());
        }

        input.close();
    }
}
